package Doctors;
import Driver.ConnectionFactory;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class DoctorDAO{
    public static void createDoctor(Doctor doctor) throws SQLException {
        Connection connection= ConnectionFactory.getConnection();
        String sql="insert into doctors values(?,?,?,?,?,?,?)";
        assert connection != null;
        PreparedStatement preparedStatement = connection.prepareStatement(sql);

        preparedStatement.setString(1,doctor.getDocID());
        preparedStatement.setString(2,doctor.getName());
        preparedStatement.setString(3,doctor.getBloodGroup());
        preparedStatement.setString(4,doctor.getSpecialization());
        preparedStatement.setString(5,doctor.getGender());
        preparedStatement.setInt(6,doctor.getAge());
        preparedStatement.setString(7,doctor.getProfile());
        preparedStatement.executeUpdate();
        System.out.println("Added doctor to the database");
    }
    public static void removeDoctor(String DocID) throws SQLException {
        Connection connection= ConnectionFactory.getConnection();
        String sql="delete from doctors where docID = ?";
        assert connection != null;
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1,DocID);
        preparedStatement.executeUpdate();
        System.out.println("Removed doctor from the database");
    }

    public static void updateDoctor(String column, String DocID,String info) throws SQLException {
        Connection connection = ConnectionFactory.getConnection();
        switch(column){
            case "name" :
                String sql = "update doctors set name = ? where docID ='"+DocID+"'";
                assert connection != null;
                PreparedStatement preparedStatement = connection.prepareStatement(sql);
                preparedStatement.setString(1,info);
                preparedStatement.executeUpdate();
                System.out.println("Updated the doctor name");
                break;
            case "bloodgroup":
                break;
        }
    }
    public static void displayDoctor() throws SQLException {
        Connection connection = ConnectionFactory.getConnection();
        String sql ="select * from doctors";
        PreparedStatement preparedStatement=connection.prepareStatement(sql);
        preparedStatement.executeQuery();
        ResultSet resultSet=preparedStatement.getResultSet();
        while (resultSet.next()){
            System.out.println(resultSet.getString("docID"));
            System.out.println(resultSet.getString("name"));
            System.out.println(resultSet.getString("specialization"));
        }
    }
    public static void createDoctorFromCSV(String CSVpath){
        try {
            BufferedReader bufferedReader = new BufferedReader(new FileReader(CSVpath));
            String patientLine;
            while ((patientLine=bufferedReader.readLine())!=null)
                createDoctor(new Doctor(patientLine));
            System.out.println("Added CSV data to the database");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
