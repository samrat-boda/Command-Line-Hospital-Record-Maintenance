package Driver;
import Doctors.*;
import Nurse.*;
import Patients.*;
import Room.*;
public class Driver {
    public static void main(String[] args) throws Exception {
/*     Doctor doctor1=new Doctor("D100","vd","o+","surgeon",
                "M",23,"permanent");
        DoctorDAO.createDoctor(doctor1);
        DoctorDAO.updateDoctor("name","D100","dino");
        Doctor doctor2=new Doctor("D101","CHANDRA","O+",
                "NEUROLOGIST","M",20,"VISITING");
        DoctorDAO.createDoctor(doctor2);
        DoctorDAO.displayDoctor();
        DoctorDAO.removeDoctor("D100");
         Patient patient1=new Patient("sam","P101",19,"f",
                 "2021-11-02","O+","3477375","dead");
        PatientDAO.createPatient(patient1);
        PatientDAO.displayPatient();
        PatientDAO.removePatient("P101");
         Nurse nurse1 =new Nurse("N101","sam",23,"m","o+");
        NurseDAO.createNurse(nurse1);
        NurseDAO.displayNurse();
          NurseDAO.removeNurse("N101");
        Room room1=new Room("R2","P101",true,"1-11-2021",
                "4-11-2021");
        RoomDAO.createRoom(room1);
       RoomDAO.displayRoom();
        RoomDAO.removeRoom("R1");
      DoctorDAO.createDoctorFromCSV(
        "C:\\VD\\IIITS\\UG_2\\sem 3\\OOPS\\project_oops\\src\\CSVfiles\\doctor.csv");
         PatientDAO.createPatientFromCSV(
                 "C:\\VD\\IIITS\\UG_2\\sem 3\\OOPS\\project_oops\\src\\CSVfiles\\patients.csv");
         NurseDAO.createNurseFromCSV(
                 "C:\\VD\\IIITS\\UG_2\\sem 3\\OOPS\\project_oops\\src\\CSVfiles\\nurse.csv");

        RoomDAO.createRoomFromCSV(
                "C:\\VD\\IIITS\\UG_2\\sem 3\\OOPS\\project_oops\\src\\CSVfiles\\rooms.csv");
        Doctor doctor1=new Doctor(
                "D110","tony","b+",
                "cardiologist","m",56,"visiting");
        DoctorDAO.createDoctor(doctor1);*/

        }
    }

