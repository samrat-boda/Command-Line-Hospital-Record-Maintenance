package Patients;
import Driver.ConnectionFactory;
import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PatientDAO {
  public static void createPatient(Patient patient) throws SQLException {

      Connection connection= ConnectionFactory.getConnection();
      String sql="insert into patients values(?,?,?,?,?,?,?,?)";
      assert connection != null;

      PreparedStatement preparedStatement = connection.prepareStatement(sql);

      preparedStatement.setString(1,patient.getPatientID());
      preparedStatement.setString(2,patient.getPatientName());
      preparedStatement.setInt(3,patient.getAge());
      preparedStatement.setString(4,patient.getGender());
      preparedStatement.setString(5,patient.getAdmissionDate());
      preparedStatement.setString(6,patient.getBloodGrp());
      preparedStatement.setString(7,patient.getPhoneNo());
      preparedStatement.setString(8,patient.getStatus());
      preparedStatement.executeUpdate();

      System.out.println("Added patient to the database");

  }
    public static void createPatientFromCSV(String CSVpath){
        try {
            BufferedReader bufferedReader = new BufferedReader(new FileReader(CSVpath));
            String doctorLine;
            while ((doctorLine=bufferedReader.readLine())!=null)
                createPatient(new Patient(doctorLine));
            System.out.println("Added CSV data to the database");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static void removePatient(String patientID) throws SQLException {
        Connection connection= ConnectionFactory.getConnection();
        String sql="delete from patients where patientID = ?";

        assert connection != null;
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1,patientID);
        preparedStatement.executeUpdate();

        System.out.println("Removed patient from the database");
    }
    public static void displayPatient() throws SQLException {
        Connection connection = ConnectionFactory.getConnection();
        String sql = "select * from patients";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.executeQuery();
        ResultSet resultSet = preparedStatement.getResultSet();
        while (resultSet.next()) {
            System.out.println(resultSet.getString("patientID"));
            System.out.println(resultSet.getString("patientName"));
            System.out.println(resultSet.getString("admissionDate"));
        }
    }
    
/*    public static void updatePatient(String column, String DocID,String info) throws SQLException {
        Connection connection = ConnectionFactory.getConnection();
        switch(column){
            case "name" :
                String sql = "update doctors set name = ? where docID ='"+DocID+"'";
                assert connection != null;
                PreparedStatement preparedStatement = connection.prepareStatement(sql);
                preparedStatement.setString(1,info);
                preparedStatement.executeUpdate();
                System.out.println("Updated the doctor name");
                break;
            case "bloodgroup":
                break;
        }
    }*/
}
