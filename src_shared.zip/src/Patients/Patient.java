package Patients;
public class Patient {

    private String patientName;
    private String patientID;
    private int age;
    private String gender;
    private String admissionDate;
    private String bloodGrp;
    private String phoneNo;
    private String status;

    //getter setters
        public String getPatientName() {return patientName;}
        public void setPatientName(String patientName) {this.patientName = patientName;}
        public String getPatientID() {return patientID;}
        public void setPatientID(String patientID) {this.patientID = patientID;}
        public int getAge() {return age;}
        public void setAge(int age) {this.age = age;}
        public String getPhoneNo() {return phoneNo;}
        public void setPhoneNo(String phoneNo) {this.phoneNo = phoneNo;}
        public String getGender() {return gender;}
        public void setGender(String gender) {this.gender = gender;}
        public String getAdmissionDate() {return admissionDate;}
        public void setAdmissionDate(String admissionDate) {this.admissionDate = admissionDate;}
        public String getBloodGrp() {return bloodGrp;}
        public void setBloodGrp(String bloodGrp) {this.bloodGrp = bloodGrp;}
        public String getStatus() {return status;}
        public void setStatus(String status) {this.status = status;}

    @Override
    public String toString() {
        return "Patient{" +
                "patientName='" + patientName + '\'' +
                ", patientID='" + patientID + '\'' +
                ", age=" + age +
                ", gender='" + gender + '\'' +
                ", admissionDate='" + admissionDate + '\'' +
                ", bloodGrp='" + bloodGrp + '\'' +
                ", phoneNo='" + phoneNo + '\'' +
                ", status='" + status + '\'' +
                '}';
    }

    //constructor
    public Patient(String patientName, String patientID, int age,
                   String gender, String admissionDate, String bloodGrp,
                   String phoneNo, String status){
        this.patientName = patientName;
        this.patientID = patientID;
        this.age = age;
        this.gender = gender;
        this.admissionDate = admissionDate;
        this.bloodGrp = bloodGrp;
        this.phoneNo = phoneNo;
        this.status = status;

    }
    public Patient(String PatientLine){
        String attributes[]=PatientLine.split(",");
        this.patientName=attributes[0];
        this.patientID=attributes[1];
        this.age=Integer.parseInt(attributes[2]);
        this.gender=attributes[3];
        this.admissionDate=attributes[4];
        this.bloodGrp=attributes[5];
        this.phoneNo=attributes[6];
        this.status=attributes[7];
    }
}
