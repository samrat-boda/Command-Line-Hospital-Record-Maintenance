package Nurse;
import Driver.ConnectionFactory;

import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class NurseDAO {

    public static void createNurse(Nurse Nurse) throws SQLException {
        Connection connection = ConnectionFactory.getConnection();
        String sql = "insert into Nurse values(?,?,?,?,?)";
        assert connection != null;

        PreparedStatement preparedStatement = connection.prepareStatement(sql);

        preparedStatement.setString(1, Nurse.getNurseID());
        preparedStatement.setString(2, Nurse.getNurseName());
        preparedStatement.setInt(3, Nurse.getAge());
        preparedStatement.setString(4, Nurse.getGender());
        preparedStatement.setString(5, Nurse.getBloodGroup());
        preparedStatement.executeUpdate();

        System.out.println("Added Nurse to the database");
    }
    public static void createNurseFromCSV(String CSVpath){
        try {
            BufferedReader bufferedReader = new BufferedReader(new FileReader(CSVpath));
            String NurseLine;
            while ((NurseLine=bufferedReader.readLine())!=null)
                createNurse(new Nurse(NurseLine));
            System.out.println("Added CSV data to the database");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static void removeNurse(String NurseID) throws SQLException {
        Connection connection= ConnectionFactory.getConnection();
        String sql="delete from Nurse where NurseID = ?";

        assert connection != null;
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1,NurseID);
        preparedStatement.executeUpdate();

        System.out.println("Removed Nurse from the database");
    }
    public static void displayNurse() throws SQLException {
        Connection connection = ConnectionFactory.getConnection();
        String sql = "select * from Nurse";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.executeQuery();
        ResultSet resultSet = preparedStatement.getResultSet();
        while (resultSet.next()) {
            System.out.println(resultSet.getString("NurseID"));
            System.out.println(resultSet.getString("NurseName"));
        }
    }
/*    public static void updateNurse(String column, String DocID,String info) throws SQLException {
        Connection connection = ConnectionFactory.getConnection();
        switch(column){
            case "name" :
                String sql = "update Nurses set name = ? where docID ='"+DocID+"'";
                assert connection != null;
                PreparedStatement preparedStatement = connection.prepareStatement(sql);
                preparedStatement.setString(1,info);
                preparedStatement.executeUpdate();
                System.out.println("Updated the Nurse name");
                break;
            case "bloodgroup":
                break;
        }
    }*/
}