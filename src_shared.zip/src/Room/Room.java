package Room;
public class Room {
     private String roomNo;
     private String patientID;
     private boolean status;
     private String admissionDate;
     private String dischargeDate;

        public String getRoomNo() {return roomNo;}
        public void setRoomNo(String roomNo) {this.roomNo = roomNo;}
        public String getPatientID() {return patientID;}
        public void setPatientID(String patientID) {this.patientID = patientID;}
        public boolean isStatus() {return status;}
        public void setStatus(boolean status) {this.status = status;}
        public String getAdmissionDate() {return admissionDate;}
        public void setAdmissionDate(String admissionDate) {this.admissionDate = admissionDate;}
        public String getDischargeDate() {return dischargeDate;}
        public void setDischargeDate(String dischargeDate) {this.dischargeDate = dischargeDate;}

        public Room(String roomNo, String patientID, boolean status, String admissionDate, String dischargeDate) {
            this.roomNo = roomNo;
            this.patientID = patientID;
            this.status = status;
            this.admissionDate = admissionDate;
            this.dischargeDate = dischargeDate;
        }
    public Room(String PatientLine){
        String attributes[]=PatientLine.split(",");
        this.roomNo  =attributes[0];
        this.patientID=attributes[1];
        this.status=Boolean.parseBoolean(attributes[2]);
        this.admissionDate=attributes[3];
        this.dischargeDate=attributes[4];
    }
    @Override
    public String toString() {
        return "Room{" +
                "roomNo='" + roomNo + '\'' +
                ", patientID='" + patientID + '\'' +
                ", status=" + status +
                ", admissionDate='" + admissionDate + '\'' +
                ", dischargeDate='" + dischargeDate + '\'' +
                '}';
    }
}
