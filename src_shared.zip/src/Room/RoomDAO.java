package Room;
import Driver.ConnectionFactory;

import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class RoomDAO {
    public static void createRoom(Room room) throws SQLException {
        Connection connection = ConnectionFactory.getConnection();
        String sql = "insert into rooms values(?,?,?,?,?)";
        assert connection != null;

        PreparedStatement preparedStatement = connection.prepareStatement(sql);

        preparedStatement.setString(1, room.getRoomNo());
        preparedStatement.setString(2, room.getPatientID());
        preparedStatement.setBoolean(3, room.isStatus());
        preparedStatement.setString(4, room.getAdmissionDate());
        preparedStatement.setString(5, room.getDischargeDate());
        preparedStatement.executeUpdate();

        System.out.println("Added Room to the database");
    }
    public static void createRoomFromCSV(String CSVpath){
        try {
            BufferedReader bufferedReader = new BufferedReader(new FileReader(CSVpath));
            String RoomLine;
            while ((RoomLine=bufferedReader.readLine())!=null)
                createRoom(new Room(RoomLine));
            System.out.println("Added CSV data to the database");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static void removeRoom(String roomNo) throws SQLException {
        Connection connection= ConnectionFactory.getConnection();
        String sql="delete from rooms where roomNo = ?";

        assert connection != null;
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1,roomNo);
        preparedStatement.executeUpdate();

        System.out.println("Removed room from the database");
    }
    public static void displayRoom() throws SQLException {
        Connection connection = ConnectionFactory.getConnection();
        String sql = "select * from rooms";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.executeQuery();
        ResultSet resultSet = preparedStatement.getResultSet();
        while (resultSet.next()) {
            System.out.println(resultSet.getString("roomNo"));
            System.out.println(resultSet.getString("patientID"));
        }
    }
    /*    public static void updateDoctor(String column, String DocID,String info) throws SQLException {
        Connection connection = ConnectionFactory.getConnection();
        switch(column){
            case "name" :
                String sql = "update doctors set name = ? where docID ='"+DocID+"'";
                assert connection != null;
                PreparedStatement preparedStatement = connection.prepareStatement(sql);
                preparedStatement.setString(1,info);
                preparedStatement.executeUpdate();
                System.out.println("Updated the doctor name");
                break;
            case "bloodgroup":
                break;
        }
    }*/
}
