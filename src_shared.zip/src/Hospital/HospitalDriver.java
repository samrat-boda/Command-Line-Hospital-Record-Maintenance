package Hospital;
import Patients.*;
import Doctors.*;
import java.sql.*;
public class HospitalDriver {
    private static final String url = "jdbc:mysql://127.0.0.1:3306/project_oops";
    private static final String username="root";
    private static final String pwd="vaibhav@2003";

    public static void addDoctor(String[] args){
        try {
            Connection connection = DriverManager.getConnection(url,username,pwd);
            PreparedStatement preparedStatement=connection.prepareStatement(
                    "insert into doctors(Name,DoctorID,Department,age) values(?,?,?,?)");
            preparedStatement.setString(1,args[1]);
            preparedStatement.setString(2,args[2]);
            preparedStatement.setString(3,args[3]);
            preparedStatement.setInt(4,Integer.parseInt(args[4]));
            preparedStatement.executeUpdate();
            System.out.println("Added Doctor to the database");
        } catch (SQLException e){
            e.printStackTrace();
        }
    }
    public static void showDoctor(String args[]){
        try {
            Connection connection = DriverManager.getConnection(url,username,pwd);
            Statement stm = connection.createStatement();
            ResultSet resultSet= stm.executeQuery("select * from doctors");
            while (resultSet.next()) {
                System.out.print(resultSet.getString(1) + "  ");
                System.out.print(resultSet.getString(2) + "  ");
                System.out.print(resultSet.getString(3) + "  ");
                System.out.println(resultSet.getInt(4));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static void main(String[] args) {
        try {
            switch (args[0]) {
                case "-add":
                    addDoctor(args);
                    break;
                case "-show":
                    showDoctor(args);
                    break;
            }
        }
        catch (ArrayIndexOutOfBoundsException e){
            System.out.println("no arguments provided");
        }
    }
}
