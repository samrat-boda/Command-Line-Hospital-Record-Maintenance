create
    definer = root@localhost procedure emp_curs()
BEGIN
DECLARE finished INTEGER DEFAULT 0;
DECLARE ename int;
DECLARE eplace int;
-- declare cursor for employee name and place
DEClARE curname CURSOR FOR SELECT idcustomer, age FROM customer;
-- declare NOT FOUND handler
DECLARE CONTINUE HANDLER FOR NOT FOUND SET finished = 1;
OPEN curname;

getname: LOOP
FETCH curname INTO ename, eplace;
IF finished = 1 THEN
LEAVE getname;
END IF;
-- build employee names
SELECT ename,eplace;
END LOOP getname;
CLOSE curname;
END;

