create
    definer = root@localhost procedure gradecourse()
begin
declare finished INTEGER DEFAULT 0;
declare c1 int;
declare c2 int;
declare c3 int;
declare c4 int;
declare sum int;
declare stud cursor for select course1, course2, course3, course4 from student_s20200010217;
declare continue handler for not found set finished = 1;
open stud;
create table grades(grade varchar(45));
getname : LOOP
    fetch stud into c1, c2, c3 ,c4;
    if finished = 1 then 
        leave getname;
    end if;
    set sum = c1+c2+c3+c4;
    if sum>=350 then 
        insert into grades values('O');
    end if;
    if sum > 300 and sum<350 then
        insert into grades values('A');
    end if;
    if sum >250 and sum <300 then
        insert into grades values('B');
    end if;
    if sum<250 then
        insert into grades values('fail');
    end if;
    end loop getname;
    close stud;
    select * from grades;
end;

