create
    definer = root@localhost procedure grade()
begin
declare name1,grade varchar(45);
declare g1,g2,g3,g4,id,total INT;
declare finish int default 0;
declare cursorStud cursor for select stu_id,stu_name,Course1,Course2,Course3,Course4 from student_s20200010217;

declare continue handler for not found set finish=1;
open cursorStud;

read_loop: LOOP
fetch cursorStud into id,name1,g1,g2,g3,g4;

if finish=1 
then
leave read_loop;
end if;
set total=g1+g2+g3+g4;

if total>=350 then
set grade="O Grade";
elseif total>=300 and total <350 then
set grade ="A Grade";
elseif total>=250 and total <200 then
set grade ="B Grade";
else 
set grade="Fail";
end if;

select id,name1,total,grade;
end LOOP;
close cursorStud;
end;

