create
    definer = root@localhost procedure netbal()
begin
select depositor.customer_name,(account.balance-loan.amount) as netBalance from (account join loan join borrower join depositor) where loan.loan_number = borrower.loan_number and account.accountnumber=depositor.account_number and depositor.customer_name=borrower.customer_name;
end;

